<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>E&amp;xit</source>
        <translation>&amp;Sair</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Arquivo</translation>
    </message>
    <message>
        <source>Internationalization Example</source>
        <translation>Exemplo de Internacionalização</translation>
    </message>
    <message>
        <source>Language: %1</source>
        <translation>Idioma: %1</translation>
    </message>
    <message>
        <source>English</source>
        <translation>Português</translation>
    </message>
    <message>
        <source>View</source>
        <translation>Visão</translation>
    </message>
    <message>
        <source>Perspective</source>
        <translation>Perspectiva</translation>
    </message>
    <message>
        <source>Isometric</source>
        <translation>Isométrico</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>Oblíquo</translation>
    </message>
    <message>
        <source>First</source>
        <translation>Primeiro</translation>
    </message>
    <message>
        <source>Second</source>
        <translation>Segundo</translation>
    </message>
    <message>
        <source>Third</source>
        <translation>Terceiro</translation>
    </message>
    <message>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
</TS>
